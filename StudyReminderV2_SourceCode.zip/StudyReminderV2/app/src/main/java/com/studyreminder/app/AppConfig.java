package com.studyreminder.app;

import java.util.ArrayList;
import java.util.List;

/**
 * Central configuration for all monitored apps.
 * Each app entry has: package name, display name, emoji, default timer (minutes), enabled state.
 */
public class AppConfig {

    public static class AppEntry {
        public String packageName;
        public String displayName;
        public String emoji;
        public int defaultMinutes;
        public String category;

        public AppEntry(String pkg, String name, String emoji, int mins, String cat) {
            this.packageName = pkg;
            this.displayName = name;
            this.emoji = emoji;
            this.defaultMinutes = mins;
            this.category = cat;
        }
    }

    public static List<AppEntry> getAllApps() {
        List<AppEntry> list = new ArrayList<>();

        // ── SHORT VIDEO ──
        list.add(new AppEntry("com.google.android.youtube",       "YouTube (Shorts)",   "▶️",  5,  "শর্ট ভিডিও"));
        list.add(new AppEntry("com.zhiliaoapp.musically",          "TikTok",             "🎵",  3,  "শর্ট ভিডিও"));
        list.add(new AppEntry("com.instagram.android",             "Instagram Reels",    "📸",  4,  "শর্ট ভিডিও"));
        list.add(new AppEntry("com.snapchat.android",              "Snapchat",           "👻",  3,  "শর্ট ভিডিও"));
        list.add(new AppEntry("com.ss.android.ugc.trill",          "TikTok (Lite)",      "🎵",  3,  "শর্ট ভিডিও"));
        list.add(new AppEntry("com.mxtech.videoplayer.ad",         "MX Player",          "🎬",  10, "শর্ট ভিডিও"));

        // ── SOCIAL MEDIA ──
        list.add(new AppEntry("com.facebook.katana",               "Facebook Reels",     "📘",  3,  "সোশ্যাল মিডিয়া"));
        list.add(new AppEntry("com.facebook.lite",                 "Facebook Lite",      "📘",  3,  "সোশ্যাল মিডিয়া"));
        list.add(new AppEntry("com.twitter.android",               "Twitter / X",        "🐦",  5,  "সোশ্যাল মিডিয়া"));
        list.add(new AppEntry("com.pinterest",                     "Pinterest",          "📌",  5,  "সোশ্যাল মিডিয়া"));
        list.add(new AppEntry("com.reddit.frontpage",              "Reddit",             "🤖",  5,  "সোশ্যাল মিডিয়া"));
        list.add(new AppEntry("com.linkedin.android",              "LinkedIn",           "💼",  10, "সোশ্যাল মিডিয়া"));

        // ── GAMES ──
        list.add(new AppEntry("com.mobile.legends",                "Mobile Legends",     "⚔️",  15, "গেম"));
        list.add(new AppEntry("com.garena.game.codm",              "Call of Duty Mobile","🔫",  15, "গেম"));
        list.add(new AppEntry("com.pubg.krmobile",                 "PUBG Mobile",        "🪂",  15, "গেম"));
        list.add(new AppEntry("com.dts.freefireth",                "Free Fire",          "🔥",  15, "গেম"));
        list.add(new AppEntry("com.supercell.clashofclans",        "Clash of Clans",     "🏰",  10, "গেম"));
        list.add(new AppEntry("com.kiloo.subwaysurf",              "Subway Surfers",     "🏃",  5,  "গেম"));
        list.add(new AppEntry("com.imangi.templerun2",             "Temple Run",         "🏃",  5,  "গেম"));

        // ── MESSAGING / ENTERTAINMENT ──
        list.add(new AppEntry("com.netflix.mediaclient",           "Netflix",            "🎥",  20, "বিনোদন"));
        list.add(new AppEntry("com.spotify.music",                 "Spotify",            "🎧",  15, "বিনোদন"));
        list.add(new AppEntry("com.whatsapp",                      "WhatsApp",           "💬",  5,  "মেসেজিং"));
        list.add(new AppEntry("org.telegram.messenger",            "Telegram",           "✈️",  5,  "মেসেজিং"));

        return list;
    }

    // Preference key for timer of a specific app
    public static String timerKey(String packageName) {
        return "timer_" + packageName.replace(".", "_");
    }

    // Preference key for enabled state
    public static String enabledKey(String packageName) {
        return "enabled_" + packageName.replace(".", "_");
    }
}
