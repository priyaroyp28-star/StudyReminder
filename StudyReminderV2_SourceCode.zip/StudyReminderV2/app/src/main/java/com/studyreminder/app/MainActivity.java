package com.studyreminder.app;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private LinearLayout containerApps;
    private Button btnStartStop;
    private TextView tvStatus;
    private boolean isRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("StudyReminder", Context.MODE_PRIVATE);
        containerApps = findViewById(R.id.containerApps);
        btnStartStop  = findViewById(R.id.btnStartStop);
        tvStatus      = findViewById(R.id.tvStatus);

        isRunning = prefs.getBoolean("isRunning", false);

        buildAppList();
        updateUI();
        requestBatteryPermission();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 100);
        }

        btnStartStop.setOnClickListener(v -> toggleService());
    }

    /** Dynamically build the list of apps grouped by category */
    private void buildAppList() {
        containerApps.removeAllViews();
        List<AppConfig.AppEntry> apps = AppConfig.getAllApps();
        String lastCategory = "";

        for (AppConfig.AppEntry app : apps) {
            // Category header
            if (!app.category.equals(lastCategory)) {
                lastCategory = app.category;
                TextView header = new TextView(this);
                header.setText("── " + app.category + " ──");
                header.setTextSize(13f);
                header.setTextColor(0xFF888888);
                header.setPadding(0, 24, 0, 4);
                header.setTypeface(null, android.graphics.Typeface.BOLD);
                containerApps.addView(header);
            }

            // App row card
            View row = LayoutInflater.from(this).inflate(R.layout.item_app_row, containerApps, false);

            TextView tvName    = row.findViewById(R.id.tvAppName);
            Switch swEnabled   = row.findViewById(R.id.swEnabled);
            SeekBar seekTimer  = row.findViewById(R.id.seekTimer);
            TextView tvTimer   = row.findViewById(R.id.tvTimer);

            // Load saved values
            boolean enabled = prefs.getBoolean(AppConfig.enabledKey(app.packageName), false);
            int savedMins   = prefs.getInt(AppConfig.timerKey(app.packageName), app.defaultMinutes);

            tvName.setText(app.emoji + " " + app.displayName);
            swEnabled.setChecked(enabled);
            seekTimer.setMax(24); // 1–25 minutes
            seekTimer.setProgress(Math.min(savedMins - 1, 24));
            tvTimer.setText(savedMins + " মিনিট");

            // Show/hide timer based on enabled
            seekTimer.setVisibility(enabled ? View.VISIBLE : View.GONE);
            tvTimer.setVisibility(enabled ? View.VISIBLE : View.GONE);

            // Switch toggle
            swEnabled.setOnCheckedChangeListener((btn, checked) -> {
                prefs.edit().putBoolean(AppConfig.enabledKey(app.packageName), checked).apply();
                seekTimer.setVisibility(checked ? View.VISIBLE : View.GONE);
                tvTimer.setVisibility(checked ? View.VISIBLE : View.GONE);
                if (isRunning) restartService();
            });

            // Seek bar change
            seekTimer.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                    int mins = p + 1;
                    tvTimer.setText(mins + " মিনিট");
                    prefs.edit().putInt(AppConfig.timerKey(app.packageName), mins).apply();
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {
                    if (isRunning) restartService();
                }
            });

            containerApps.addView(row);
        }
    }

    private void toggleService() {
        if (!isRunning) {
            if (!hasUsageStatsPermission()) {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                Toast.makeText(this, "⚠️ 'পড়তে বস!' অ্যাপটি চালু করুন, তারপর Start করুন", Toast.LENGTH_LONG).show();
                return;
            }
            // Check at least one app is enabled
            boolean anyEnabled = false;
            for (AppConfig.AppEntry a : AppConfig.getAllApps()) {
                if (prefs.getBoolean(AppConfig.enabledKey(a.packageName), false)) {
                    anyEnabled = true; break;
                }
            }
            if (!anyEnabled) {
                Toast.makeText(this, "⚠️ কমপক্ষে একটি অ্যাপ চালু করুন!", Toast.LENGTH_SHORT).show();
                return;
            }
            startMonitorService();
            isRunning = true;
        } else {
            stopService(new Intent(this, AppMonitorService.class));
            isRunning = false;
        }
        prefs.edit().putBoolean("isRunning", isRunning).apply();
        updateUI();
    }

    private void startMonitorService() {
        Intent intent = new Intent(this, AppMonitorService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
    }

    private void restartService() {
        if (isRunning) {
            stopService(new Intent(this, AppMonitorService.class));
            startMonitorService();
        }
    }

    private void updateUI() {
        if (isRunning) {
            btnStartStop.setText("⏹ বন্ধ করুন");
            btnStartStop.setBackgroundColor(0xFFE53935);
            tvStatus.setText("✅ চালু — সোশ্যাল মিডিয়া পর্যবেক্ষণ করছে");
            tvStatus.setTextColor(0xFF2E7D32);
        } else {
            btnStartStop.setText("▶ শুরু করুন");
            btnStartStop.setBackgroundColor(0xFF43A047);
            tvStatus.setText("⏸ বন্ধ আছে");
            tvStatus.setTextColor(0xFFB71C1C);
        }
    }

    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private void requestBatteryPermission() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        isRunning = prefs.getBoolean("isRunning", false);
        updateUI();
    }
}
