package com.studyreminder.app;

import android.app.*;
import android.app.usage.*;
import android.content.*;
import android.media.*;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import java.util.*;

public class AppMonitorService extends Service {

    private static final String TAG = "StudyReminder";
    private static final String CHANNEL_ID = "study_reminder_v2";
    private static final int NOTIF_ID = 1;

    private SharedPreferences prefs;
    private Handler mainHandler;
    private Runnable monitorTask;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private MediaPlayer sirenPlayer;

    // State
    private String activeApp = "";          // currently open watched app package
    private int activeTimerMinutes = 5;     // timer for that app
    private long appEnteredAt = 0;          // when user entered the app
    private boolean countingDown = false;

    private Handler countdownHandler;
    private Runnable countdownTask;
    private int countdownSecs = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("StudyReminder", Context.MODE_PRIVATE);
        mainHandler = new Handler(Looper.getMainLooper());
        countdownHandler = new Handler(Looper.getMainLooper());

        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotif("পর্যবেক্ষণ চলছে..."));
        initTTS();
        startPolling();
    }

    /* ── TTS ── */
    private void initTTS() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("bn", "BD"));
                if (res < 0) tts.setLanguage(Locale.getDefault());
                tts.setSpeechRate(0.85f);
                tts.setPitch(0.75f);
                ttsReady = true;
            }
        });
    }

    /* ── POLLING every 1 second ── */
    private void startPolling() {
        monitorTask = new Runnable() {
            @Override public void run() {
                tick();
                mainHandler.postDelayed(this, 1000);
            }
        };
        mainHandler.post(monitorTask);
    }

    private void tick() {
        String current = getForegroundApp();
        if (current == null) return;

        // Is this a watched + enabled app?
        AppConfig.AppEntry entry = findEnabledEntry(current);

        if (entry != null) {
            // ─ User is in a watched app ─
            if (!current.equals(activeApp)) {
                // Just switched to this app
                activeApp = current;
                activeTimerMinutes = prefs.getInt(AppConfig.timerKey(entry.packageName), entry.defaultMinutes);
                appEnteredAt = System.currentTimeMillis();
                stopCountdown();
                startCountdown(activeTimerMinutes * 60);
                updateNotif("📱 " + entry.emoji + " " + entry.displayName + " — ⏱ কাউন্টডাউন শুরু");
                Log.d(TAG, "Entered: " + entry.displayName + " timer=" + activeTimerMinutes + "m");
            }
        } else {
            // ─ Not a watched app ─
            if (!activeApp.isEmpty()) {
                activeApp = "";
                stopCountdown();
                updateNotif("পর্যবেক্ষণ চলছে...");
            }
        }
    }

    /* ── COUNTDOWN ── */
    private void startCountdown(int totalSeconds) {
        countingDown = true;
        countdownSecs = totalSeconds;

        countdownTask = new Runnable() {
            int secs = totalSeconds;
            @Override public void run() {
                if (activeApp.isEmpty()) return; // left the app

                if (secs <= 0) {
                    fireReminder();
                    return;
                }

                // Last 5 seconds
                if (secs <= 5) {
                    updateNotif("⚠️ " + secs + " সেকেন্ড বাকি! পড়তে যান!");
                    if (secs == 5 && ttsReady) speak(secs + " সেকেন্ড বাকি, পড়তে বস!");
                } else {
                    int m = secs / 60, s = secs % 60;
                    AppConfig.AppEntry e = findEnabledEntry(activeApp);
                    String name = e != null ? e.emoji + " " + e.displayName : activeApp;
                    updateNotif(name + " | ⏱ " + String.format("%02d:%02d", m, s) + " পরে বাজবে");
                }

                secs--;
                countdownHandler.postDelayed(this, 1000);
            }
        };
        countdownHandler.post(countdownTask);
    }

    private void stopCountdown() {
        countingDown = false;
        if (countdownTask != null) {
            countdownHandler.removeCallbacks(countdownTask);
            countdownTask = null;
        }
    }

    /* ── FIRE REMINDER ── */
    private void fireReminder() {
        AppConfig.AppEntry e = findEnabledEntry(activeApp);
        String appName = e != null ? e.displayName : "সোশ্যাল মিডিয়া";

        Log.d(TAG, "FIRE reminder for " + appName);
        updateNotif("🚨 পড়তে বস! পড়তে বস! পড়তে বস!");

        // Vibrate
        Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vib != null) {
            long[] pat = {0, 600, 200, 600, 200, 600};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                vib.vibrate(VibrationEffect.createWaveform(pat, -1));
            else vib.vibrate(pat, -1);
        }

        // Siren
        playSiren();

        // Voice "পড়তে বস!" × 3
        if (ttsReady) {
            mainHandler.postDelayed(() -> speak("পড়তে বস!"), 300);
            mainHandler.postDelayed(() -> speak("পড়তে বস!"), 2200);
            mainHandler.postDelayed(() -> speak("পড়তে বস!"), 4100);
        }

        // Auto loop — restart countdown after 7 seconds
        mainHandler.postDelayed(() -> {
            if (!activeApp.isEmpty()) {
                startCountdown(activeTimerMinutes * 60);
            }
        }, 7000);
    }

    private void playSiren() {
        try {
            if (sirenPlayer != null) { sirenPlayer.stop(); sirenPlayer.release(); sirenPlayer = null; }
            Uri alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            sirenPlayer = MediaPlayer.create(this, alarmUri);
            if (sirenPlayer == null) {
                // fallback
                alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                sirenPlayer = MediaPlayer.create(this, alarmUri);
            }
            if (sirenPlayer != null) {
                sirenPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
                sirenPlayer.start();
                mainHandler.postDelayed(() -> {
                    if (sirenPlayer != null) { sirenPlayer.stop(); sirenPlayer.release(); sirenPlayer = null; }
                }, 3500);
            }
        } catch (Exception ex) { Log.e(TAG, "siren error: " + ex.getMessage()); }
    }

    private void speak(String text) {
        if (!ttsReady || tts == null) return;
        Bundle b = new Bundle();
        b.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_ALARM);
        tts.speak(text, TextToSpeech.QUEUE_ADD, b, "r" + System.currentTimeMillis());
    }

    /* ── HELPERS ── */
    private AppConfig.AppEntry findEnabledEntry(String pkg) {
        for (AppConfig.AppEntry a : AppConfig.getAllApps()) {
            if (a.packageName.equals(pkg) && prefs.getBoolean(AppConfig.enabledKey(a.packageName), false))
                return a;
        }
        return null;
    }

    private String getForegroundApp() {
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 5000, now);
            if (stats == null || stats.isEmpty()) return null;
            UsageStats top = null;
            for (UsageStats s : stats)
                if (top == null || s.getLastTimeUsed() > top.getLastTimeUsed()) top = s;
            return top != null ? top.getPackageName() : null;
        } catch (Exception e) { return null; }
    }

    /* ── NOTIFICATION ── */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "পড়তে বস! রিমাইন্ডার",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotif(String text) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("📚 পড়তে বস!")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void updateNotif(String text) {
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF_ID, buildNotif(text));
    }

    /* ── LIFECYCLE ── */
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopCountdown();
        if (mainHandler != null) mainHandler.removeCallbacks(monitorTask);
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (sirenPlayer != null) { sirenPlayer.release(); }
    }
}
